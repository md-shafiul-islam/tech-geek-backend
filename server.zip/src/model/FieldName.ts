import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
import { InputFormTemplate } from "./InputFormTemplate";

@Entity({ name: "fiel_name" })
export class FieldName {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: "field_name" })
  fieldName: string;

  title: string;

  inputFormTemplate: InputFormTemplate;
}
